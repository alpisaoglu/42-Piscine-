	42 is a global education initiative that proposes a new way of learning technology: no teachers,
	no classrooms, students learning from their fellow students (peer to peer learning), with a
	methodology that develops both computing and life skills. The 42 cursus is free for whoever is
	approved in its selection process. The so-called "C Piscine", a 26-day C programming bootcamp,
	is the last stage in the selection process for becoming a "cadet" (42's student).
